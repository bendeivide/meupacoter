# Funcoes auxiliares

# Soma
soma <- function (a, b) {
          calculo <- a + b
          return(calculo)
}

#Subtracao
subtra <- function (a, b) {
            calculo <- a - b
            return(calculo)
}

# Multiplicacao
multi <- function (a, b) {
           calculo <- a * b
           return(calculo)
}

# Divisao
divisi <- function (a, b) {
            calculo <- a / b
            return(calculo)
}
